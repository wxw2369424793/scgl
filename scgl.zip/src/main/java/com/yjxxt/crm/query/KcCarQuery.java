package com.yjxxt.crm.query;

import com.yjxxt.crm.base.BaseQuery;

public class KcCarQuery extends BaseQuery {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
