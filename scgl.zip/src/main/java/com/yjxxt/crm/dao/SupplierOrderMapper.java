package com.yjxxt.crm.dao;

import com.yjxxt.crm.base.BaseMapper;
import com.yjxxt.crm.vo.SupplierOrder;

public interface SupplierOrderMapper extends BaseMapper<SupplierOrder,Integer> {

}